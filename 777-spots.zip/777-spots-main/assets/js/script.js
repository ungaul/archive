const map = L.map('map', {
    preferCanvas: true,
    maxBounds: [[-90, -180], [90, 180]],
    maxZoom: 18,
    minZoom: 3
}).setView([50, 15], 5);

const googleStreets = L.tileLayer("http://{s}.google.com/vt/lyrs=m&x={x}&y={y}&z={z}", {
    maxZoom: 20,
    subdomains: ['mt0', 'mt1', 'mt2', 'mt3']
});
googleStreets.addTo(map);

const myRenderer = L.canvas({ padding: 0.5 });

const canvasIcon = L.canvasIcon({
    iconSize: [20, 20],
    iconAnchor: [10, 10],
    drawIcon: function(canvas, type) {
        const ctx = canvas.getContext("2d");
        const img = new Image();
        img.src = 'assets/img/togo.png';
        img.onload = function() {
            ctx.clearRect(0, 0, canvas.width, canvas.height);
            ctx.drawImage(img, 0, 0, canvas.width, canvas.height);
        };
    }
});

let allPoints = [];
$.ajax({
    url: 'assets/js/data.json',
    method: 'GET',
    dataType: 'json',
    success: function (data) {
        allPoints = data;
        updateVisibleMarkers();
    },
    error: function (err) {
        console.error('Error loading JSON data:', err);
    }
});

function updateVisibleMarkers() {
    const bounds = map.getBounds();
    const zoom = map.getZoom();

    let visiblePoints = allPoints.filter(point =>
        bounds.contains([point.coordinates.lat, point.coordinates.lng])
    );

    if (zoom < 8) {
        visiblePoints = visiblePoints.filter((point, index) => index % 5 === 0);
    } else if (zoom < 10) {
        visiblePoints = visiblePoints.filter((point, index) => index % 3 === 0);
    }

    // Supprime les marqueurs existants (ceux utilisant canvasIcon)
    map.eachLayer(layer => {
        if (layer instanceof L.Marker && layer.options.icon && layer.options.icon.options && layer.options.icon.options.drawIcon) {
            map.removeLayer(layer);
        }
    });

    visiblePoints.forEach(point => {
        const marker = L.marker([point.coordinates.lat, point.coordinates.lng], {
            icon: canvasIcon,
            renderer: myRenderer
        });

        marker.on('mouseover', () => {
            const popup = document.getElementById('popup');
            const popupContent = document.getElementById('popup-content');
            if (popup && popupContent) {
                popupContent.textContent = point.note || 'Aucune note disponible';
                popup.style.opacity = 1;
            }
        });

        marker.on('mouseout', () => {
            const popup = document.getElementById('popup');
            if (popup) {
                popup.style.opacity = 0;
            }
        });

        // Au clic gauche, on ouvre l'URL définie dans le champ google_url s'il a été modifié,
        // sinon on utilise la propriété "note" du point.
        marker.on('click', () => {
            const googleURL = $("#google_url").val();
            if (googleURL && googleURL !== "Left Click") {
                window.open(googleURL, '_blank');
            } else if (point.note) {
                window.open(point.note, '_blank');
            }
        });

        // Au clic droit, on ouvre l'URL définie dans le champ note_url s'il a été modifié,
        // sinon on utilise la propriété "url" du point.
        marker.on('contextmenu', (event) => {
            if (event.originalEvent) {
                event.originalEvent.preventDefault();
            }
            const noteURL = $("#note_url").val();
            if (noteURL && noteURL !== "Right Click") {
                window.open(noteURL, '_blank');
            } else if (point.url) {
                window.open(point.url, '_blank');
            }
        });

        marker.addTo(map);
    });
}

map.on('moveend', updateVisibleMarkers);
map.on('zoomend', updateVisibleMarkers);

// Gestion du mode sombre
$("#dark_mode").on('change', function() {
    const darkModeSheet = $("#darkModeSheet");
    if ($(this).is(":checked")) {
        darkModeSheet.attr("href", "assets/css/dark.css");
    } else {
        darkModeSheet.attr("href", "assets/css/light.css");
    }
});

// Gestion du panneau de réglages avec jQuery
$(document).ready(function() {
    $("#settings-button").click(function() {
        $("#settings-container").addClass("active");
    });

    $("#settings-container").click(function(e) {
        if ($(e.target).is("h1, h2, label, input")) {
            return;
        }
        $(this).removeClass("active");
    });
});
