var polygonJson = {
  type: "FeatureCollection",
  features: [
    // {
    //   type: "Feature",
    //   properties: { stroke: "#555555", "stroke-width": 2, "stroke-opacity": 1, fill: "#555555", "fill-opacity": 0.5, name: "rectangle" },
    //   geometry: {
    //     type: "Polygon",
    //     coordinates: [
    //       [
    //         [4.8357, 45.7640],
    //         [2.3522, 48.8566],
    //         [0.5792, 44.8378],
    //         [5.3698, 43.2965],
    //       ],
    //     ],
    //   },
    // },
    // {
    //   type: "Feature",
    //   properties: { stroke: "#555555", "stroke-width": 2, "stroke-opacity": 1, fill: "#555555", "fill-opacity": 0.5, name: "polygon" },
    //   geometry: {
    //     type: "Polygon",
    //     coordinates: [
    //       [
    //         [4.8357, 45.7640],
    //         [2.3522, 48.8566],
    //         [0.5792, 44.8378],
    //         [5.3698, 43.2965],
    //       ],
    //     ],
    //   },
    // },
  ],
};
