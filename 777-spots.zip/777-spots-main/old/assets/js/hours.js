// Fichier hours.js

function displayOpeningHours(weekdayText) {
    let currentDay = getCurrentDay();
    let hoursHtml = `<div class="current-day">${weekdayText[currentDay]}</div>`;

    for (let i = 0; i < weekdayText.length; i++) {
        if (i !== currentDay) {
            hoursHtml += `<div class="other-day hidden">${weekdayText[i]}</div>`;
        }
    }

    hoursHtml += '<button class="expand-hours">Expand Hours</button>';
    $("#hours-container").html(hoursHtml);

    // Toggle to show/hide other days
    $(".expand-hours").on("click", function () {
        $(".other-day").toggleClass("hidden");
        $(this).text($(this).text() === "Expand Hours" ? "Collapse Hours" : "Expand Hours");
    });
}

// Helper pour obtenir le jour actuel
function getCurrentDay() {
    return new Date().getDay(); // Retourne 0 pour dimanche, 1 pour lundi, etc.
}
