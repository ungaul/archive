// Fichier markers.js

// Fonction pour ajouter des markers à partir de données
function addMarkers(data) {
    data.forEach((line, index) => {
        var latitude = parseFloat(line["Latitude"]);
        var longitude = parseFloat(line["Longitude"]);
        var title = line["Title"];
        if (!isNaN(latitude) && !isNaN(longitude)) {
            var iconUrl = line["Type"] === "Photo Spot" ? "assets/img/togo.png" : "assets/img/star.png";
            var customIcon = L.icon({
                iconUrl: iconUrl,
                iconSize: [20, 20],
                iconAnchor: [10, 10],
            });
            var marker = L.marker([latitude, longitude], { id: index, icon: customIcon });
            markers.addLayer(marker);
        }
    });
}
