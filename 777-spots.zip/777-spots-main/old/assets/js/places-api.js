// Fichier places-api.js

function fetchPlaceDetails(title, callback) {
    const service = new google.maps.places.PlacesService(document.createElement('div'));
    const request = { query: title, fields: ["place_id"] };

    service.findPlaceFromQuery(request, function (results, status) {
        if (status === google.maps.places.PlacesServiceStatus.OK && results.length > 0) {
            const placeId = results[0].place_id;
            const detailsRequest = {
                placeId: placeId,
                fields: ["name", "formatted_address", "rating", "types", "website", "photos", "opening_hours", "reservable"]
            };

            service.getDetails(detailsRequest, function (place, status) {
                if (status === google.maps.places.PlacesServiceStatus.OK) {
                    callback(place);
                } else {
                    callback(null);
                }
            });
        } else {
            callback(null);
        }
    });
}

function displayPlaceDetails(place) {
    $(".prefecture").text("Address: " + place.formatted_address || "Address not found.");
    $(".rate").text("Rating: " + place.rating || "Rating not available.");
    $(".type").text("Type: " + (place.types[0] || "Type not available"));
    $(".website").attr("href", place.website || "#").text(place.website || "Website not available.");

    if (place.photos && place.photos.length > 0) {
        const photoUrl = place.photos[0].getUrl({ maxWidth: 400 });
        $(".sidebarimg").css("background-image", "url('" + photoUrl + "')");
    }
}
