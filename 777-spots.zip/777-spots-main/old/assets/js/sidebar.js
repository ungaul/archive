// Fichier sidebar.js

function updateSidebar(properties) {
    if (properties) {
        $(".labelType").text(properties["Type"]);
        $(".title").text(properties["Title"]);

        fetchPlaceDetails(properties["Title"], function (placeDetails) {
            if (placeDetails) {
                displayPlaceDetails(placeDetails);
            }
        });

        // Gestion des notes
        let noteText = properties["Note"];
        if (noteText.includes("https")) {
            $(".note").html('Note : <a href="' + noteText + '" target="_blank">' + noteText + '</a>');
        } else if (noteText.trim() === "") {
            $(".note").text("No note");
        } else {
            $(".note").text("Note : " + noteText);
        }

        $(".id").text("#" + (globalData.indexOf(properties) + 2));
        $(".latitude").text(properties["Latitude"]);
        $(".longitude").text(properties["Longitude"]);
    }
}
