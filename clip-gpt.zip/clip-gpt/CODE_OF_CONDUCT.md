# Code of Conduct

- Be polite and constructive.
- No spam, advertising, or illegal content.
- Comment your code clearly.
