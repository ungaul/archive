# Investir: Guide (Frontend)

Simple static frontend for an educational investment guide.
Built with HTML, CSS, and jQuery. No backend.

## Features

- Dark/light mode toggle (with localStorage)
- Style switcher
- Responsive layout
- Scrollable tables on mobile