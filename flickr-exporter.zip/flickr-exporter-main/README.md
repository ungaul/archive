# 📸 Flickr Data Extractor

This Python script allows you to extract metadata from your Flickr export `.zip` file and convert it into a clean `.xlsx` spreadsheet.

## ✅ Features

- File picker to select your Flickr `.zip` export
- Automatic extraction of all `photo*.json` files
- Parses and compiles metadata including:
  - Photo ID, name, description
  - View/favorite/comment counts
  - Date taken/imported
  - Photo and original image URLs
  - License
  - Latitude & longitude (if available)
  - Tags and albums
- Outputs an Excel file (`.xlsx`) with full Unicode support (Japanese, emoji, etc.)

## 📦 Requirements

- Python 3.7+
- [openpyxl](https://pypi.org/project/openpyxl/) (for `.xlsx` export)

Install with:

```bash
pip install openpyxl