import os
import json
import tempfile
import zipfile
import tkinter as tk
from tkinter import filedialog
from openpyxl import Workbook

def select_zip_file():
    root = tk.Tk()
    root.withdraw()
    zip_path = filedialog.askopenfilename(
        title="Select your Flickr ZIP export file",
        filetypes=[("ZIP files", "*.zip")]
    )
    return zip_path

def extract_zip(zip_path):
    temp_dir = tempfile.mkdtemp()
    with zipfile.ZipFile(zip_path, 'r') as zip_ref:
        zip_ref.extractall(temp_dir)
    print(f"[INFO] ZIP extracted to: {temp_dir}")
    return temp_dir

def load_photo_jsons(folder_path):
    data = []
    for root, _, files in os.walk(folder_path):
        for filename in files:
            if filename.startswith("photo") and filename.endswith(".json"):
                full_path = os.path.join(root, filename)
                try:
                    with open(full_path, 'r', encoding='utf-8') as file:
                        photo = json.load(file)
                        if isinstance(photo, list):
                            print(f"[WARN] File {filename} contains a list of entries.")
                            data.extend(photo)
                        elif isinstance(photo, dict):
                            data.append(photo)
                        else:
                            print(f"[WARN] Unknown data type in {filename}: {type(photo)}")
                except json.JSONDecodeError as e:
                    print(f"[ERROR] Failed to parse JSON in {filename}: {e}")
    print(f"[INFO] Loaded {len(data)} photo entries.")
    return data

def extract_rows(photo_data):
    rows = []
    for idx, photo in enumerate(photo_data):
        if not isinstance(photo, dict):
            print(f"[WARN] Skipping non-dict item at index {idx}: type={type(photo)}")
            continue

        geo_data = photo.get("geo", [])
        latitude = longitude = ""
        if isinstance(geo_data, list) and geo_data:
            first_geo = geo_data[0]
            if isinstance(first_geo, dict):
                latitude = first_geo.get("latitude", "")
                longitude = first_geo.get("longitude", "")

        tags = [tag.get("tag", "") for tag in photo.get("tags", []) if isinstance(tag, dict)]
        albums = [album for album in photo.get("albums", []) if isinstance(album, dict)]

        row = [
            photo.get("id", ""),
            photo.get("name", ""),
            photo.get("description", ""),
            photo.get("count_views", ""),
            photo.get("count_faves", ""),
            photo.get("count_comments", ""),
            photo.get("date_taken", ""),
            photo.get("date_imported", ""),
            photo.get("photopage", ""),
            photo.get("original", ""),
            photo.get("license", ""),
            latitude,
            longitude,
            ", ".join(tags),
            ", ".join([a.get("title", "") for a in albums]),
            ", ".join([a.get("url", "") for a in albums])
        ]
        print(f"[INFO] Processed photo ID: {photo.get('id')}")
        rows.append(row)
    return rows

def write_to_excel(rows, output_path="flickr_photos.xlsx"):
    headers = [
        "ID", "Name", "Description", "Views", "Faves", "Comments Count",
        "Date Taken", "Date Imported", "Photo Page", "Original URL", "License",
        "Latitude", "Longitude", "Tags", "Album Titles", "Album URLs"
    ]

    wb = Workbook()
    ws = wb.active
    ws.title = "Flickr Data"

    ws.append(headers)
    for row in rows:
        ws.append(row)

    wb.save(output_path)
    print(f"[INFO] Excel file saved to: {output_path}")

if __name__ == "__main__":
    zip_file = select_zip_file()
    if zip_file:
        extracted_folder = extract_zip(zip_file)
        photos = load_photo_jsons(extracted_folder)
        rows = extract_rows(photos)
        write_to_excel(rows)
    else:
        print("[INFO] No file selected.")
