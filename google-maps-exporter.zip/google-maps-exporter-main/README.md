# Google Maps Exporter

This repository contains scripts to generate KML files from place data using Google Maps coordinates.

## Prerequisites

First, go to [takeout.google.com](https://takeout.google.com) and download the CSV files by toggling only the "Saved".

## Setup

1. Install dependencies:

```bash
pip install -r requirements.txt
```

2. Create a `.env` file in the project folder with your Google Maps API key:

```
GOOGLE_MAPS_API=<APIKEYHERE>
```

## Usage

### 1. Calculate Coordinates

Run `add_coordinates.py` to calculate coordinates using the Google Maps Geocoding API. This will add a `coordinates` column to your CSV.

**Attention:** Some places are stores containing "data" URLs. For these, you need to manually convert the URL to coordinates by:

1. Opening the URL in Google Maps.
2. Right-clicking the location.
3. Selecting "What's here?" to get the coordinates.
4. Enter the coordinates manually in the CSV.

### 2. Convert CSV to KML

Run `csv2kml.py` to convert your CSV into a KML file. This script also preserves any Notes entered in Google Maps for each place.

## Notes

* Ensure all coordinates are accurate, especially manually added ones.
* The scripts assume the CSV has proper headers for location data and notes.

## Contributions
Contributions are welcome! Open an issue or submit a pull request to propose improvements.

## License
This project is licensed under the MIT License. See the `LICENSE.md` file for more details.