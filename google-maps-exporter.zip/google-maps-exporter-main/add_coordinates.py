import pandas as pd
import re
import requests
from dotenv import load_dotenv
import os
import time

load_dotenv()
API_KEY = os.getenv("GOOGLE_MAPS_API")
if not API_KEY:
    raise ValueError("GOOGLE_MAPS_API key not found in .env")

CSV_INPUT = input("Enter the path to your CSV file: ").strip()
CSV_OUTPUT = CSV_INPUT

df = pd.read_csv(CSV_INPUT, sep=None, engine='python')
df.columns = df.columns.str.strip()

if "Coordinates" not in df.columns:
    df["Coordinates"] = ""

decimal_regex = re.compile(r"^-?\d+(\.\d+)?,\-?\d+(\.\d+)?$")

def single_dms_to_decimal(dms):
    match = re.match(r"(\d+)°(\d+)'([\d\.]+)\"?([NSEW])", dms.strip())
    if not match:
        return None
    deg, minutes, seconds, direction = match.groups()
    dec = float(deg) + float(minutes)/60 + float(seconds)/3600
    if direction in ['S', 'W']:
        dec = -dec
    return dec

def dms_pair_to_decimal(coord_str):
    if not isinstance(coord_str, str):
        return None
    parts = coord_str.strip().split()
    if len(parts) != 2:
        return None
    lat = single_dms_to_decimal(parts[0])
    lng = single_dms_to_decimal(parts[1])
    if lat is None or lng is None:
        return None
    return f"{lat},{lng}"

def get_coordinates_from_api(place_name):
    base_url = "https://maps.googleapis.com/maps/api/geocode/json"
    params = {"address": place_name, "key": API_KEY}
    response = requests.get(base_url, params=params)
    if response.status_code != 200:
        print(f"API error for {place_name}: {response.status_code}")
        return None, None
    data = response.json()
    if data.get("status") != "OK" or not data.get("results"):
        print(f"No result for {place_name} ({data.get('status')})")
        return None, None
    location = data["results"][0]["geometry"]["location"]
    return location["lat"], location["lng"]

for index, row in df.iterrows():
    coord = row.get("Coordinates")
    if pd.notna(coord) and decimal_regex.match(str(coord)):
        continue
    title = row.get("Title")
    if isinstance(title, str):
        dms_coord = dms_pair_to_decimal(title)
        if dms_coord:
            df.at[index, "Coordinates"] = dms_coord
            continue
    if isinstance(title, str) and title.strip() != "":
        lat, lng = get_coordinates_from_api(title)
        if lat is not None and lng is not None:
            df.at[index, "Coordinates"] = f"{lat},{lng}"
            print(f"{title} -> {lat},{lng}")
        else:
            print(f"Could not retrieve coordinates for {title}")
        # time.sleep(0.1)
    else:
        df.at[index, "Coordinates"] = ""

df.to_csv(CSV_OUTPUT, index=False)
print(f"\nFinal CSV saved as {CSV_OUTPUT}")
