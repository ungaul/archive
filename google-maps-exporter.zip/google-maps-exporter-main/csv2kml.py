import pandas as pd
from simplekml import Kml
import os

CSV_INPUT = input("Enter the path to your CSV file: ").strip()
df = pd.read_csv(CSV_INPUT)

df = df.dropna(subset=['Coordinates'])

kml = Kml()

for _, row in df.iterrows():
    try:
        lat, lon = map(float, row['Coordinates'].split(','))
        title = str(row['Title'])
        note = str(row['Note'])
        kml.newpoint(name=title, description=note, coords=[(lon, lat)])
    except:
        continue

folder = os.path.dirname(CSV_INPUT)
base_name = os.path.splitext(os.path.basename(CSV_INPUT))[0]
kml_output = os.path.join(folder, f"{base_name}.kml")

kml.save(kml_output)
print(f"KML file created successfully: {kml_output}")
