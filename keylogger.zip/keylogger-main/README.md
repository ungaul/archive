# Windows Keylogger

## Overview
This project is a Windows keylogger that logs keystrokes, reconstructs human-readable input, and periodically sends the data to a Google Apps Script webhook (which can log to Google Sheets). It is written in C++ and designed for educational and research purposes only.

---

## Table of Configurable Values

| Define         | Description                                                      | Options/Values                | Default      |
|---------------|------------------------------------------------------------------|-------------------------------|--------------|
| `visible`     | Show or hide the console window                                  | `visible`, `invisible`        | `visible`    |
| `bootwait`    | Wait for system boot before starting                             | `bootwait`, `nowait`          | `bootwait`   |
| `FORMAT`      | Logging format: 0=default, 10=dec, 16=hex                        | `0`, `10`, `16`               | `0`          |
| `mouseignore` | Ignore mouse clicks                                              | define or comment out         | defined      |
| `nostartup`   | Disable autostart and self-install                               | `startup`, `nostartup`        | `nostartup`  |

---

## How It Works
1. **Keystroke Logging:** Hooks into Windows keyboard events and logs keystrokes.
2. **Buffering:** Stores raw and human-readable keystrokes in memory.
3. **Sending Data:** Every 15 seconds, sends buffered data to a Google Apps Script webhook as JSON.
4. **Google Apps Script:** Receives the POST request and appends the data to a Google Sheet.

---

## Setup Instructions

### 1. Google Apps Script Webhook
- Open [Google Apps Script](https://script.google.com/).
- Create a new project and paste the contents of [googleAppScript.js](googleAppScript.js).
- Replace `PasteTheValueHere` with your Google Sheet ID.
- Match the sheet tab name with line 6 (default: `Log`).
- Deploy as a web app ("Anyone" can access):
  - Click **Deploy > New deployment**
  - Select **Web app**
  - Set access to **Anyone**
  - Copy the **Webhook ID**.

### 2. Set the Webhook Path in Environment
- Set the environment variable `WEBHOOK_ID` in Windows: `Edit the System Environment Variables` > `Environment Variables...` > `New...` > Set WEBHOOK_ID as name and the ID you copied as value.

### 3. Build the Keylogger
- Open the `windows/` directory in Visual Studio or your preferred C++ IDE.
- Make sure you link against `wininet.lib`.
- Adjust the defines at the top of `klog_main.cpp` as needed.
- Build the project.

---

## Data Sent to Webhook

| Field     | Description                        |
|-----------|------------------------------------|
| `user`    | Username of the machine            |
| `ip`      | Public IP address                  |
| `datetime`| Timestamp (ISO format)             |
| `raw`     | Raw keystroke log                  |
| `decoded` | Human-readable keystroke log       |
| `format`  | Keyboard layout (e.g., 00000409)   |

---

## Uninstall
To fully remove the keylogger from the system, follow these steps:

### 1. Kill the Running Process
- Open **Task Manager** (`Ctrl + Shift + Esc`)
- Look for a process named `chatgpt.exe`
- Right-click and select **End Task**

### 2. If `startup` was enabled
1. Navigate to: `%localappdata%\OpenAI\`
2. Delete the `.exe` file
3. Open Regedit and navigate to `HKEY_CURRENT_USER\Software\Microsoft\Windows\CurrentVersion\Run\OpenAI`
4. Find the entry and delete it

### 4. (Optional) Remove Environment Variable
If you added `WEBHOOK_ID` to your environment:
1. Go to `Edit the System Environment Variables` > `Environment Variables...`
2. Remove or edit the variable named `WEBHOOK_ID`

### License
Distributed under the [LICENSE](LICENSE.md).
Feel free to open an issue or pull request if you have any questions, requests, or want to contribute.