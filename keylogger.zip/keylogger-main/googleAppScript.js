// Paste this code in Google Apps Script by changing line 5 with the Google Sheet ID as well as changing the Sheet Name

function doPost(e) {
    try {
      var ss = SpreadsheetApp.openById("PasteTheValueHere");
      var sheet = ss.getSheetByName("Log");

      if (!sheet) {
        throw new Error("Sheet 'Log' not found");
      }

      var data = JSON.parse(e.postData.contents);
      var now = new Date();
      var user = data.user || "unknown";
      var ip = data.ip || "unknown";
      var raw = (data.raw || "").replace(/[\r\n]+/g, " ").trim();
      var decoded = (data.decoded || "").replace(/[\r\n]+/g, " ").trim();
      var format = data.format || "unknown";

      sheet.appendRow([now, user, raw, decoded, format, ip]);

      return ContentService.createTextOutput("OK");
    } catch (err) {
      return ContentService.createTextOutput("ERROR: " + err.toString());
    }
  }
